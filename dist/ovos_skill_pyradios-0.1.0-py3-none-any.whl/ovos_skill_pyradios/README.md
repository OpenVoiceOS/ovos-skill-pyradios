# <img src='./res/radio-tuner.svg' card_color='#40DBB0' width='50' height='50' style='vertical-align:bottom'/> Pyradios

OCP skill for [Pyradios](https://github.com/andreztz/pyradios), a client for the [Radio Browser API](https://api.radio-browser.info/)

![Mycroft GUI playing radio](./gui.png)

## Examples

* "play tsf jazz radio"
* "play tsf jazz on pyradios"

## Credits

* [Pyradios](https://github.com/andreztz/pyradios)

## Category

Entertainment

## Tags

\#audio
\#music
\#OCP
\#entertainment
